public class Lab3_3_3 {
    public static void main(String[] args) {
        long [] memory  = new long [Integer.MAX_VALUE-4];
    }
}
